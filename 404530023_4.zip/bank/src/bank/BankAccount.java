/**
 * 
 *404530023������
 *
 */


package bank;

import java.util.ArrayList;//�]�wINPORT
//�إ�BankAccount class
public class BankAccount {//�]���ܼ� status,i,id,balance,initialbalance
	private String status="open";
	public int i;
	public int id;
	public double balance,initialbalance;
	private ArrayList<Double> transactions;
	public  BankAccount( )//�إ�BankAccount( )
	{
		id=-1;
		balance=-1;
		transactions = new ArrayList();
	}
	public  BankAccount(int ids)
	{
		id = ids;
		balance= -1;
		transactions = new ArrayList();
	}
public  BankAccount(int ids ,double initialbalance )//��J�ܼ�BankAccount( )
{
	id = ids;
	balance=initialbalance;
	transactions = new ArrayList();
	
}
public void deposit(double amount)//�إ�deposit(double amount)
{
	if(isOpen()&& amount>0)
	{
		addTransaction(amount);
		balance+=amount;
	}
	
}
	public void withdraw(double amount)//�إ�withdraw(double amount)
	{
		if(isOpen()&& balance>=amount&&amount>0)
		{
			addTransaction(amount);
			balance-=amount;
		}
		
	}
	public void suspend()//�إ�suspend()
	{
		if(status!="suspend")
		{
			status="suspend";
		}
	}
	public void close()//�إ� close()
	{
		if(status!="close")
		{
			status="open";
			withdraw(balance);
			status="close";
		}
	}
	public void reOpen()//�إ�reOpen()
	{
		if(status!="open")
		{
			status="open";
		}
	}
	public boolean isOpen()//�إ�isOpen()
	{
		return status.equals("open");
	}
	public boolean  isSuspend()//�إ�isSuspend()
	{
		return status.equals( "suspend");
	}
	public boolean isClose()//�إ�isClose()
	{
		return status.equals("close");
	}
	public void addTransaction(double amount)//�إ�addTransaction(double amount)
	{
		transactions.add(amount);
	}
	public String getTransactions()//�إ�getTransactions()
	{
		String trans="Account"+"  "+"#"+id+"transactions:   "+"\n";
		
		for(i=1;i<=transactions.size();i++)
		{
			trans+=i+":"+transactions.get(i-1)+ "\n";
		}
		return trans+"End of transactions \n";
	}
	public int retrieveNumberOfTransactions()//�إ�retrieveNumberOfTransactions()
	{
		return transactions.size();
	}
	public String getStatus()//�إ�getStatus()
	{
		return status;
	}
	public int getTranscation()//�إ�getTranscation()
	{
		return transactions.size();
	}
}

