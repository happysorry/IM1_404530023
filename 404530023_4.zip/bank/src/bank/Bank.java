package bank;

import java.util.ArrayList;

public class Bank {
	ArrayList<BankAccount> Account = new ArrayList<BankAccount>();
	public BankAccount findbankaccount(int accountNumber)
	{
		BankAccount account = null;
		for (BankAccount account1 : Account) 
		{
			if (account1.id == accountNumber)
				account = account1;
		}
		return account;
}
	public void addAccount(int accountNumber, double initialBalance)
	{
		BankAccount newBankAccount=new BankAccount(accountNumber, initialBalance);
		Account.add(newBankAccount);
	}
	public void deposit(int accountNumber, double initialBalance)
	{
		 findbankaccount(accountNumber).deposit(initialBalance);
	}
	public void withdraw(int accountNumber, double initialBalance)
	{
 findbankaccount( accountNumber).withdraw(initialBalance);;
	}
	public double getBalance(int accountNumber)
	{
		return findbankaccount( accountNumber).balance;
	}
	public void suspendAccount(int accountNumber)
	{
		findbankaccount( accountNumber).suspend();
	}
	public void reOpenAccount(int accountNumber)
	{
		findbankaccount( accountNumber).reOpen();
	}
	public void closeAccount(int accountNumber)
	{
		findbankaccount( accountNumber).close();
	}
	public String getAccountStatus(int accountNumber)
	{
		return findbankaccount( accountNumber).getStatus();
	}
	public String summarizeAccountTransactions(int accountNumber)
	{
		return findbankaccount( accountNumber).getTransactions();
	}
	public  String summarizeAllAccounts()
	{
		String trans="Bank Account Summary \n\n"+"Account    Balance     #Transactions    Status";
		for(BankAccount account1:Account)
		{
			trans+= Integer.toString(account1.id)+"    ";
			trans+=Double.toString(account1.balance)+"    ";
			trans+=Integer.toString(account1.getTranscation())+"    ";
			trans+=account1.getStatus()+"\n";
		}
		return trans+"End of Account Summary ";
	}
}